import Die
def main():
    for i in range(0,5):
        die = Die.Die(6)
        print(die.roll())
main()
