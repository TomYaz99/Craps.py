# Craps Game - CS110 Final Project
### By: Mark Caldropoli, Emily Lakic, Jordana Simon, Samantha Chu and Danielle O'Neal

##Command to run: python3 Craps.py
##Purpose of classes: 
###RollingDie.py - This class implements a rolling die. Creates the die as well as the number of dots on it. Draws die while it is rolling and when it is not. sSets the table boundaries and sets the die off the table. Starts the die rolling and if it is rolling, returns true, if else, returns false.
###Craps.py - This class positions the window to the center of screen and opens the score window when main game window is exited.
